<div class="offcanvas-container" id="mobile-menu">
   <a class="account-link" href="<?php echo url('/account-orders'); ?>">
      <div class="user-info">
         <h6 class="user-name">Daniel Adams</h6>
      </div>
   </a>
   <nav class="offcanvas-menu">
      <ul class="menu">
         <li class="has-megamenu <?php echo e(Request::is('/') ? "active" : ""); ?>"><a href="<?php echo url('/'); ?>"><span>Home</span></a></li>
         <li class="has-megamenu <?php echo e(Request::is('about') ? "active" : ""); ?>"><a href="<?php echo url('/about'); ?>"><span>About</span></a></li>
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li class="has-megamenu"><a href="<?php echo e(url('category/'.$category->slug)); ?>"><span><?php echo e($category->name); ?></span></a></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </nav>
</div>
<header class="navbar navbar-sticky navbar-stuck">
   <div class="site-branding">
      <div class="inner">
         <!-- Off-Canvas Toggle (#mobile-menu)-->
         <a class="offcanvas-toggle menu-toggle" href="#mobile-menu" data-toggle="offcanvas"></a>
         <!-- Site Logo--><a class="site-logo" href="<?php echo url('/index'); ?>">
         <img src="<?php echo e(asset('images/logo-store.png')); ?>" alt="General Store"></a>
      </div>
   </div>
   <!-- Main Navigation-->
   <nav class="site-menu">
      <ul>
         <li class="has-megamenu <?php echo e(Request::is('/') ? "active" : ""); ?>"><a href="<?php echo url('/'); ?>"><span>Home</span></a></li>
         <li class="has-megamenu <?php echo e(Request::is('about') ? "active" : ""); ?>"><a href="<?php echo url('/about'); ?>"><span>About</span></a></li>
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li class="has-megamenu"><a href="<?php echo e(url('category/'.$category->slug)); ?>"><span><?php echo e($category->name); ?></span></a></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </nav>
   <!-- Toolbar-->
   <div class="toolbar">
      <div class="inner">
         <div class="tools">
            <div class="account">
               <a href="<?php echo url('/account-orders'); ?>"></a>
               <i class="icon-head"></i>
               <ul class="toolbar-dropdown">
                  <li class="sub-menu-user">
                     <div class="user-info">
                        <h6 class="user-name">
                           <?php if(!Auth::guest()): ?>
                           <?php echo Auth::user()->name;; ?>

                           <?php endif; ?>
                           <?php if(Auth::guest()): ?>
                           Welcome, Guest
                           <?php endif; ?>
                        </h6>
                     </div>
                  </li>
                  <?php if(!Auth::guest()): ?>
                  <li><a href="<?php echo e(url('account')); ?>">My account</a></li>
                  <li><a href="<?php echo e(url('orders')); ?>">Orders List</a></li>
                  <li class="sub-menu-separator"></li>
                  <li><a href="<?php echo e(url('logout')); ?>"> <i class="icon-unlock"></i>Logout</a></li>
                  <?php endif; ?>
                  <?php if(Auth::guest()): ?>
                  <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                  <li><a href="<?php echo e(url('register')); ?>">Register</a></li>
                  <?php endif; ?>
               </ul>
            </div>
            <div class="cart">
               <a href="<?php echo url('/cart'); ?>"></a><i class="glyphicon glyphicon-shopping-cart"></i><span class="subtotal">
               <?php if( isset($shopcart_sum) ){ echo '$ ' .$shopcart_sum; } else echo '$ 0.00' ?>
               </span>
               <div class="toolbar-dropdown">
                  <?php $__currentLoopData = $shopcart_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopcartlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="dropdown-product-item">
                     <a class="dropdown-product-thumb">
                        <img src="<?php echo url('images/products/'.$shopcartlist['firstimage']['product_id'].'/'.$shopcartlist['firstimage']['image'].''); ?>" alt="<?php echo $shopcartlist['product']->name; ?>">
                     </a>
                     <div class="dropdown-product-info">
                        <a class="dropdown-product-title" href="">
                           <?php echo $shopcartlist['product']->name; ?></a>
                        <span class="dropdown-product-details">
                        <?php echo $shopcartlist->quantity; ?>x       
                        <?php echo '$'.$shopcartlist['product']->price; ?>

                        </span>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  <div class="toolbar-dropdown-group">
                     <div class="column"><span class="text-lg">Total:</span></div>
                     <div class="column text-right"><span class="text-lg text-medium">
                        <?php if( isset($shopcart_sum) ){ echo '$'.$shopcart_sum; } else echo '$0.00' ?>
                        </span>
                     </div>
                  </div>
                  <div class="toolbar-dropdown-group">
                     <div class="column"><a class="btn btn-default" href="<?php echo url('/cart'); ?>">View Cart</a></div>
                     <div class="column"><a class="btn btn-success" href="<?php echo url('/checkout'); ?>">Checkout</a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</header>