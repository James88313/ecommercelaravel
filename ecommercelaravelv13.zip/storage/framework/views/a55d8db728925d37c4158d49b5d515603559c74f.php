<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Create Customer</div>
                <div class="panel-body">
                    <?php echo Form::open(['url' => 'users']); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="col-md-6">
                        	<h2>Personal Details</h2>
                        	<?php echo Form::label('name', 'Name'); ?>

                        	<?php echo Form::input('text', 'name', null, ['class' => 'form-control', 'autofocus', 'placeholder' => 'Name']); ?>

                        	<?php echo Form::label('email', 'Email'); ?>

                        	<?php echo Form::input('email', 'name', null, ['class' => 'form-control', 'placeholder' => 'E-mail']); ?>

                        	<?php echo Form::label('password', 'Password'); ?>

                        	<?php echo Form::input('password', 'password', null, ['class' => 'form-control', 'placeholder' => 'Password']); ?>

                        	<?php echo Form::label('password-confirm', 'Confirm Password'); ?>

                        	<?php echo Form::input('password', 'password-confirm', null, ['class' => 'form-control', 'placeholder' => 'Password Confirm']); ?>

                        	<?php echo Form::label('cpf', 'CPF'); ?>

                        	<?php echo Form::input('text', 'cpf', null, ['class' => 'form-control', 'autofocus', 'placeholder' => 'CPF']); ?>

                        	<?php echo Form::label('birth', 'Birth'); ?>

                        	<?php echo Form::input('date', 'birth', null, ['class' => 'form-control', 'autofocus', 'placeholder' => 'Birth']); ?>

                        	<?php echo Form::label('gender', 'Gender'); ?><br>
                        	<?php echo e(Form::radio('sex', 'male' )); ?>Male
                        	<?php echo e(Form::radio('sex', 'female')); ?>Female
                        
                    </div>
                    <div class="col-md-6">
                    	<h2>Contact Details</h2>
                    	<?php echo Form::label('cep', 'CEP'); ?>

                        <?php echo Form::input('text', 'cep', null, ['class' => 'form-control', 'placeholder' => 'CEP']); ?>

                        <?php echo Form::label('estate', 'Estate'); ?>

                        <?php echo Form::input('text', 'estate', null, ['class' => 'form-control', 'placeholder' => 'Estate']); ?>

                        <?php echo Form::label('city', 'City'); ?>

                        <?php echo Form::input('text', 'city', null, ['class' => 'form-control', 'placeholder' => 'City']); ?>

                        <?php echo Form::label('address', 'Address'); ?>

                        <?php echo Form::input('text', 'address', null, ['class' => 'form-control', 'placeholder' => 'Address']); ?>

                        <?php echo Form::label('newsletter', 'Receibe Newsletter?'); ?><br>
                        <?php echo e(Form::radio('sex', 1, 'yes' )); ?>Yes
                        <?php echo e(Form::radio('sex', 'no')); ?>No
                        <br>
                        <hr>
                        <br>
                        <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>