<?php $__env->startSection('content'); ?>
<div class="row">
<h2>Account</h2>
	<div class="col-md-3">
		<label>Name:</label>
		<?php echo e(Auth::user()->name); ?><br>
		<label>Email:</label>
		<?php echo e(Auth::user()->email); ?><br>
		<label>CPF:</label>
		<?php echo e(Auth::user()->cpf); ?><br>
		<label>Birth:</label>
		<?php echo e(Auth::user()->birth); ?><br>
	</div>
	<div class="col-md-3">
		<label>Phone:</label>
		<?php echo e(Auth::user()->phone); ?><br>
		<label>Postal code:</label>
		<?php echo e(Auth::user()->cep); ?><br>
		<label>Estate:</label>
		<?php echo e(Auth::user()->estate); ?><br>
		<label>City:</label>
		<?php echo e(Auth::user()->city); ?><br>
		<label>Address:</label>
		<?php echo e(Auth::user()->address); ?><br>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>