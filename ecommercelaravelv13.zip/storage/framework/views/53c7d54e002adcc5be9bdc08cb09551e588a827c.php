<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Add Category
                    <a class="pull-right" href="<?php echo e(url('categories')); ?>">View Categories</a>
                </div>
                <div class="panel-body">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>                
                <?php endif; ?>
                    <?php echo Form::open(['url' => 'categories']); ?>               
                        <?php echo Form::label('name', 'Name'); ?>

                        <?php echo Form::input('text', 'name', null, ['class' => 'form-control', 'autofocus', 'placeholder' => 'Name']); ?>

						<?php echo Form::label('desc', 'Description'); ?>

                        <?php echo Form::input('textarea', 'description', '', ['class' => 'form-control', 'placeholder' => 'Description']); ?>

						<?php echo Form::label('image', 'Image'); ?>

                        <?php echo Form::file('category_image'); ?>

                        <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>