<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $shopcart_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopcartlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-3">
        <div class="panel panel-primary">
        <h3><?php echo $shopcartlist['product']->name; ?></h3>
        <p>
        	<div class="col-md-8" style="padding: 0px">
        		<img src="<?php echo url('images/products/'.$shopcartlist['firstimage']->product_id.'/'.$shopcartlist['firstimage']->image.''); ?>" class="img-responsive" style="max-height: 150px;">
        	</div>
        	<div class="col-md-4" style="padding: 10px 0px 0px 0px">
        		Qt: <?php echo $shopcartlist['product']->quantity; ?>

        		<br>
        		$ <?php echo number_format($shopcartlist->product_value/100,2); ?>

        	</div>

        	<div class="row"> </div>

        	<div class="col-md-12" style="text-align: right;">
        		<a href="<?php echo url('/cart/remove/'.$shopcartlist->id.''); ?>">
        			Remove this
        		</a>
        	</div>

        </p>
         </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>