<div class="offcanvas-container" id="mobile-menu"><a class="account-link" href="account-orders.html">
        <div class="user-ava"><img src="img/account/user-ava-md.jpg" alt="Daniel Adams">
        </div>
        <div class="user-info">
          <h6 class="user-name">Daniel Adams</h6>
        </div></a>
      <nav class="offcanvas-menu">
        <ul class="menu">
          <li class="has-megamenu"><a href="home"><span>Home</span></a></li>
          <li class="has-megamenu"><a href="about"><span>About</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Laptops</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Cellphones</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Gadgets</span></a></li>
        </ul>
      </nav>
</div>
<header class="navbar navbar-sticky navbar-stuck">
      <div class="site-branding">
        <div class="inner">
          <!-- Off-Canvas Toggle (#mobile-menu)-->
          <a class="offcanvas-toggle menu-toggle" href="#mobile-menu" data-toggle="offcanvas"></a>
          <!-- Site Logo--><a class="site-logo" href="index.html">
          <img src="<?php echo e(asset('images/logo-store.png')); ?>" alt="General Store"></a>
        </div>
      </div>
      <!-- Main Navigation-->
      <nav class="site-menu">
        <ul>
          <li class="has-megamenu <?php echo e(Request::is('/') ? "active" : ""); ?>"><a href="/"><span>Home</span></a></li>
          <li class="has-megamenu <?php echo e(Request::is('about') ? "active" : ""); ?>"><a href="about"><span>About</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Laptops</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Cellphones</span></a></li>
          <li class="has-megamenu"><a href="index.html"><span>Gadgets</span></a></li>
        </ul>
      </nav>
      <!-- Toolbar-->
      <div class="toolbar">
        <div class="inner">
          <div class="tools">
            <div class="account"><a href="account-orders.html"></a>
              <i class="icon-head"></i>
              <ul class="toolbar-dropdown">
                <li class="sub-menu-user">
                  <div class="user-info">
                    <h6 class="user-name">Daniel Adams</h6>
                  </div>
                </li>
                  <li><a href="account-profile.html">My account</a></li>
                  <li><a href="account-orders.html">Orders List</a></li>
                <li class="sub-menu-separator"></li>
                <li><a href="#"> <i class="icon-unlock"></i>Logout</a></li>
              </ul>
            </div>
            <div class="cart"><a href="cart.html"></a><i class="glyphicon glyphicon-shopping-cart"></i><span class="subtotal">R$289.68</span>
              <div class="toolbar-dropdown">
                <div class="dropdown-product-item"><span class="dropdown-product-remove"><i class="icon-cross"></i></span><a class="dropdown-product-thumb" href="shop-single.html"><img src="img/cart-dropdown/01.jpg" alt="Product"></a>
                  <div class="dropdown-product-info"><a class="dropdown-product-title" href="shop-single.html">Unionbay Park</a><span class="dropdown-product-details">1 x $43.90</span></div>
                </div>
                <div class="dropdown-product-item"><span class="dropdown-product-remove"><i class="icon-cross"></i></span><a class="dropdown-product-thumb" href="shop-single.html"><img src="img/cart-dropdown/02.jpg" alt="Product"></a>
                  <div class="dropdown-product-info"><a class="dropdown-product-title" href="shop-single.html">Daily Fabric Cap</a><span class="dropdown-product-details">2 x $24.89</span></div>
                </div>
                <div class="dropdown-product-item"><span class="dropdown-product-remove"><i class="icon-cross"></i></span><a class="dropdown-product-thumb" href="shop-single.html"><img src="img/cart-dropdown/03.jpg" alt="Product"></a>
                  <div class="dropdown-product-info"><a class="dropdown-product-title" href="shop-single.html">Haan Crossbody</a><span class="dropdown-product-details">1 x $200.00</span></div>
                </div>
                <div class="toolbar-dropdown-group">
                  <div class="column"><span class="text-lg">Total:</span></div>
                  <div class="column text-right"><span class="text-lg text-medium">$289.68&nbsp;</span></div>
                </div>
                <div class="toolbar-dropdown-group">
                  <div class="column"><a class="btn btn-default" href="cart.html">View Cart</a></div>
                  <div class="column"><a class="btn btn-success" href="checkout-address.html">Checkout</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>