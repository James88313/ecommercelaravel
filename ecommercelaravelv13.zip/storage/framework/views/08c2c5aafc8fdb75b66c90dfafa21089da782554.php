<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Product List
                    <a class="pull-right" href="<?php echo e(url('admin/products/create')); ?>">Add Product</a>
                </div>

                <div class="panel-body">
                    <table class="table">
                        <th>Id</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Tags</th>
                        <th>Actions</th>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->category->name); ?></td>
                                <td><?php echo e($product->brand->name); ?></td>
                                <td>
                                <?php $__currentLoopData = $product->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="label label-default"><?php echo e($tag->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <!-- <a href="products/<?php echo e($product->id); ?>/edit" class="btn btn-default">Edit</a> -->
                                    <?php echo Form::open(['method' => 'DELETE', 'url' => url('admin/products/'.$product->id.''), 'style' => 'display:inline;']); ?>

                                <button type="submit" class="btn btn btn-danger">Delete</a>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>