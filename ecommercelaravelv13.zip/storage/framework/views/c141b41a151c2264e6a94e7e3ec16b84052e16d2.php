<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Customers List
                    <a class="pull-right" href="<?php echo e(url('admin/users/create')); ?>">Add Customer</a>
                </div>
                <div class="panel-body">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                    <table class="table">
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>CPF</th>
                        <th>Birth</th>
                        <th>Phone</th>
                        <th>Actions</th>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->cpf); ?></td>
                            <td><?php echo e($user->birth); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td>
                                <a href="<?php echo url('admin/users/'.$user->id.'/edit'); ?>" class="btn btn-default">Edit</a>
                                <?php echo Form::open(['method' => 'DELETE', 'url' => url('admin/users/'.$user->id.''), 'style' => 'display:inline;']); ?>

                                <button type="submit" class="btn btn btn-danger">Delete</a>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>