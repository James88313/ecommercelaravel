<?php $__env->startSection('content'); ?>

<div id="products">

    <h2>Products</h2>

    <div class="owl-carousel">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="product">
            <?php if($product['firstimage']['image'] != null): ?>
            <img src="<?php echo url('images/products/'.$product->id.'/'.$product['firstimage']['image'].''); ?>" />
            <?php else: ?>
            <img src="<?php echo url('images/products/no-image.jpg'); ?>" />
            <?php endif; ?>
            <h3><?php echo e($product->name); ?></h3>

            <span class="brand"><?php echo e($product->brand->name); ?></span>

            <span class="price">$ <?php echo number_format($product->price/100,2); ?></span>
            <a href="<?php echo url('/details/'.$product->id.'/'.$product->slug.''); ?>">[+] details</a>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>

<div id="brands">

    <h2>Brands</h2>

	<div class="owl-carousel">

	 <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	 	<div>

	 		<img src="<?php echo e(URL::asset('images/brands/'.$brand->image)); ?>" alt="<?php echo e($brand->name); ?>" />

	 	</div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>

</div>

<script>

	$(document).ready(function(){

  $('.owl-carousel').owlCarousel({

    loop:true,

    margin:10,

    responsiveClass:true,

    responsive:{

        0:{

            items:1,

            nav:false

        },

        600:{

            items:2,

            nav:false

        },

        1000:{

            items:4,

            nav:false,

            loop:false

        }

    }

})

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>