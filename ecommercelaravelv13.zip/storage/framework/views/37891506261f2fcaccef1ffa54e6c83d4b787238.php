<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Categories List
                    <a class="pull-right" href="<?php echo e(url('categories/create')); ?>">Add Category</a>
                </div>
                <div class="panel-body">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                    <table class="table">
                        <th>Id</th>
                        <th>Name</th>
						<th>Description</th>
						<th>Image</th>
                        <th>Actions</th>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
							<td><?php echo e($category->description); ?></td>
							<td><?php echo e($category->image); ?> <a class="imagelink btn btn-default pull-right colorbox" data-fancybox href="../storage/categories/<?php echo e($category->id); ?>/<?php echo e($category->image); ?>">Open Image</a></td>
                            <td>
                                <a href="tags/<?php echo e($tag->id); ?>/edit" class="btn btn-default">Edit</a>
                                <?php echo Form::open(['method' => 'DELETE', 'url' => '/tags/'.$tag->id, 'style' => 'display:inline;']); ?>

                                <button type="submit" class="btn btn btn-danger">Delete</a>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>