<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Coupon List
                    <a class="pull-right" href="<?php echo e(url('admin/coupons/create')); ?>">Add Coupon</a>
                </div>

                <div class="panel-body">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                    <table class="table">
                        <th>Id</th>
                        <th>Name</th>
						<th>Code</th>
						<th>Discount</th>
                        <th>Actions</th>
                        <tbody>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($coupon->id); ?></td>
                            <td><?php echo e($coupon->name); ?></td>
							<td><?php echo e($coupon->code); ?></td>
							<td><?php echo e($coupon->discount); ?></td>
                            <td>
                                <a href="<?php echo url('admin/coupons/'.$coupon->id.'/edit'); ?>" class="btn btn-default">Edit</a>
                                <?php echo Form::open(['method' => 'DELETE', 'url' => url('admin/coupons/'.$coupon->id.''), 'style' => 'display:inline;']); ?>

                                <button type="submit" class="btn btn btn-danger">Delete</a>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>